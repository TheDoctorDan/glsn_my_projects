#!/usr/local/bin/perl

print "Location: /thanks.html", "\n\n";

exit (0);
